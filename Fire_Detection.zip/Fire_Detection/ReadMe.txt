At first run the python script in cmd
using folowing command
python detect_fire.py bonfire.jpg

it it gives a moduleError:cv2 not found
then execute this command in cmd
pip install opencv_python
<?php 


$output = shell_exec("python detect_fire.py candle.jpg");
echo $output;

?>
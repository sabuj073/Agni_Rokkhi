import cv2 as cv
import  numpy as np
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('testme', help="Path o the image")
arguments = parser.parse_args()

frame = cv.imread(arguments.testme)

blur = cv.GaussianBlur(frame,(21,21),0)
hsv = cv.cvtColor(blur,cv.COLOR_BGR2HSV)

lower = [18,50,50]
upper = [35,255,255]
lower = np.array(lower,dtype="uint8")
upper = np.array(upper, dtype="uint8")
mask = cv.inRange(hsv,lower,upper)

output = cv.bitwise_and(frame, hsv, mask=mask)
no_red = cv.countNonZero(mask)
#cv.imshow("Agni_Rokki",output)
#cv.imshow("Original",frame)
if int(no_red)>20000:
    print("Fire")
else:
    print("No Fire")

k = cv.waitKey(0)
